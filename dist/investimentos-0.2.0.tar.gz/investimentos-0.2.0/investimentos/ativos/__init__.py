from ativos.api_yahoofinance import *
from ativos.webscrap_fii import *
from ativos.webscrap_investidor import *
